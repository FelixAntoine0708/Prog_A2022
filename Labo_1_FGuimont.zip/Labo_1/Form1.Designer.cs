﻿namespace Labo_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnRemoveSpace = new System.Windows.Forms.Button();
            this.btnInverseCar = new System.Windows.Forms.Button();
            this.btnDoubleCar = new System.Windows.Forms.Button();
            this.btnJumpCar = new System.Windows.Forms.Button();
            this.btnMajMin = new System.Windows.Forms.Button();
            this.btnOneSpace = new System.Windows.Forms.Button();
            this.btnInverseWrd = new System.Windows.Forms.Button();
            this.btnNbWord = new System.Windows.Forms.Button();
            this.btnRotate = new System.Windows.Forms.Button();
            this.btnAscii = new System.Windows.Forms.Button();
            this.btnPassWrd = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // btnRemoveSpace
            // 
            this.btnRemoveSpace.Location = new System.Drawing.Point(19, 184);
            this.btnRemoveSpace.Name = "btnRemoveSpace";
            this.btnRemoveSpace.Size = new System.Drawing.Size(193, 30);
            this.btnRemoveSpace.TabIndex = 0;
            this.btnRemoveSpace.Text = "Retirer Espaces";
            this.btnRemoveSpace.UseVisualStyleBackColor = true;
            this.btnRemoveSpace.Click += new System.EventHandler(this.btnRemoveSpace_Click);
            // 
            // btnInverseCar
            // 
            this.btnInverseCar.Location = new System.Drawing.Point(19, 220);
            this.btnInverseCar.Name = "btnInverseCar";
            this.btnInverseCar.Size = new System.Drawing.Size(193, 30);
            this.btnInverseCar.TabIndex = 1;
            this.btnInverseCar.Text = "Inverse Car";
            this.btnInverseCar.UseVisualStyleBackColor = true;
            this.btnInverseCar.Click += new System.EventHandler(this.btnInverseCar_Click);
            // 
            // btnDoubleCar
            // 
            this.btnDoubleCar.Location = new System.Drawing.Point(19, 256);
            this.btnDoubleCar.Name = "btnDoubleCar";
            this.btnDoubleCar.Size = new System.Drawing.Size(193, 30);
            this.btnDoubleCar.TabIndex = 2;
            this.btnDoubleCar.Text = "Doubler Car";
            this.btnDoubleCar.UseVisualStyleBackColor = true;
            this.btnDoubleCar.Click += new System.EventHandler(this.btnDoubleCar_Click);
            // 
            // btnJumpCar
            // 
            this.btnJumpCar.Location = new System.Drawing.Point(19, 292);
            this.btnJumpCar.Name = "btnJumpCar";
            this.btnJumpCar.Size = new System.Drawing.Size(193, 30);
            this.btnJumpCar.TabIndex = 3;
            this.btnJumpCar.Text = "Saute Un Car";
            this.btnJumpCar.UseVisualStyleBackColor = true;
            this.btnJumpCar.Click += new System.EventHandler(this.btnJumpCar_Click);
            // 
            // btnMajMin
            // 
            this.btnMajMin.Location = new System.Drawing.Point(19, 328);
            this.btnMajMin.Name = "btnMajMin";
            this.btnMajMin.Size = new System.Drawing.Size(193, 30);
            this.btnMajMin.TabIndex = 4;
            this.btnMajMin.Text = "Maj. et Min.";
            this.btnMajMin.UseVisualStyleBackColor = true;
            this.btnMajMin.Click += new System.EventHandler(this.btnMajMin_Click);
            // 
            // btnOneSpace
            // 
            this.btnOneSpace.Location = new System.Drawing.Point(19, 364);
            this.btnOneSpace.Name = "btnOneSpace";
            this.btnOneSpace.Size = new System.Drawing.Size(193, 30);
            this.btnOneSpace.TabIndex = 5;
            this.btnOneSpace.Text = "Un Seul Espace";
            this.btnOneSpace.UseVisualStyleBackColor = true;
            this.btnOneSpace.Click += new System.EventHandler(this.btnOneSpace_Click);
            // 
            // btnInverseWrd
            // 
            this.btnInverseWrd.Location = new System.Drawing.Point(257, 184);
            this.btnInverseWrd.Name = "btnInverseWrd";
            this.btnInverseWrd.Size = new System.Drawing.Size(193, 30);
            this.btnInverseWrd.TabIndex = 6;
            this.btnInverseWrd.Text = "Inverse Mots";
            this.btnInverseWrd.UseVisualStyleBackColor = true;
            this.btnInverseWrd.Click += new System.EventHandler(this.btnInverseWrd_Click);
            // 
            // btnNbWord
            // 
            this.btnNbWord.Location = new System.Drawing.Point(257, 220);
            this.btnNbWord.Name = "btnNbWord";
            this.btnNbWord.Size = new System.Drawing.Size(193, 30);
            this.btnNbWord.TabIndex = 7;
            this.btnNbWord.Text = "Compte Mots";
            this.btnNbWord.UseVisualStyleBackColor = true;
            this.btnNbWord.Click += new System.EventHandler(this.btnNbWord_Click);
            // 
            // btnRotate
            // 
            this.btnRotate.Location = new System.Drawing.Point(257, 256);
            this.btnRotate.Name = "btnRotate";
            this.btnRotate.Size = new System.Drawing.Size(193, 30);
            this.btnRotate.TabIndex = 8;
            this.btnRotate.Text = "Rotation";
            this.btnRotate.UseVisualStyleBackColor = true;
            this.btnRotate.Click += new System.EventHandler(this.btnRotate_Click);
            // 
            // btnAscii
            // 
            this.btnAscii.Location = new System.Drawing.Point(257, 292);
            this.btnAscii.Name = "btnAscii";
            this.btnAscii.Size = new System.Drawing.Size(193, 30);
            this.btnAscii.TabIndex = 9;
            this.btnAscii.Text = "Ascii";
            this.btnAscii.UseVisualStyleBackColor = true;
            this.btnAscii.Click += new System.EventHandler(this.btnAscii_Click);
            // 
            // btnPassWrd
            // 
            this.btnPassWrd.Location = new System.Drawing.Point(257, 328);
            this.btnPassWrd.Name = "btnPassWrd";
            this.btnPassWrd.Size = new System.Drawing.Size(193, 30);
            this.btnPassWrd.TabIndex = 10;
            this.btnPassWrd.Text = "Mot de passe";
            this.btnPassWrd.UseVisualStyleBackColor = true;
            this.btnPassWrd.Click += new System.EventHandler(this.btnPassWrd_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(257, 364);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(193, 30);
            this.btnQuit.TabIndex = 11;
            this.btnQuit.Text = "Quitter";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(16, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Champ de Saisie:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(16, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Résultat:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(19, 26);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(431, 20);
            this.textBox1.TabIndex = 14;
            this.textBox1.Text = "Allo le mode";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox2.Location = new System.Drawing.Point(19, 103);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(431, 20);
            this.textBox2.TabIndex = 15;
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(462, 450);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnPassWrd);
            this.Controls.Add(this.btnAscii);
            this.Controls.Add(this.btnRotate);
            this.Controls.Add(this.btnNbWord);
            this.Controls.Add(this.btnInverseWrd);
            this.Controls.Add(this.btnOneSpace);
            this.Controls.Add(this.btnMajMin);
            this.Controls.Add(this.btnJumpCar);
            this.Controls.Add(this.btnDoubleCar);
            this.Controls.Add(this.btnInverseCar);
            this.Controls.Add(this.btnRemoveSpace);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Lab 1 Félix-Antoine Guimont";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRemoveSpace;
        private System.Windows.Forms.Button btnInverseCar;
        private System.Windows.Forms.Button btnDoubleCar;
        private System.Windows.Forms.Button btnJumpCar;
        private System.Windows.Forms.Button btnMajMin;
        private System.Windows.Forms.Button btnOneSpace;
        private System.Windows.Forms.Button btnInverseWrd;
        private System.Windows.Forms.Button btnNbWord;
        private System.Windows.Forms.Button btnRotate;
        private System.Windows.Forms.Button btnAscii;
        private System.Windows.Forms.Button btnPassWrd;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Timer timer1;
    }
}

